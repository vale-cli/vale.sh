Vale brand assets
=================

vale-mark*.svg / .png      The mark alone. Grass for light backgrounds, -dark for dark ones,
                           black/white for mono.
vale-logo*.svg / .png      The horizontal lockup: mark plus wordmark.
                           -dark is for dark backgrounds; -black/-white are mono.
vale-icon-*.png            Opaque 1024px squares for avatars. Let the platform round the corners.
vale-social.png            1200x630 card for link previews.

Colors
  Grass        #62A527   the mark and buttons, on light backgrounds
  Grass, light #90D454   the same, on dark backgrounds
  Ink          #12150E   type on light backgrounds
  Paper        #F7F9F3   light background
  Graphite     #0E100C   dark background

The wordmark is Newsreader Semibold (SIL Open Font License), shipped as paths.

Guidelines and current files: https://vale.sh/brand
